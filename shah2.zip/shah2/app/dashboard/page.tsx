"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getCurrentUser, logout, isAuthenticated } from "@/lib/auth"
import { getPlaces, addPlace, updatePlace, deletePlace, toggleStatus, type Place } from "@/lib/places"
import { getProfile } from "@/lib/profile"
import { ProfileDialog } from "@/components/profile-dialog"
import { PlaceCard } from "@/components/place-card"
import { PlaceDialog } from "@/components/place-dialog"
import { Notification } from "@/components/notification"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, LogOut, Search, Plane, User } from "lucide-react"

export default function DashboardPage() {
  const router = useRouter()
  const [places, setPlaces] = useState<Place[]>([])
  const [filteredPlaces, setFilteredPlaces] = useState<Place[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingPlace, setEditingPlace] = useState<Place | null>(null)
  const [profileDialogOpen, setProfileDialogOpen] = useState(false)
  const [userProfile, setUserProfile] = useState({ name: "", photoUrl: "" })
  const [notification, setNotification] = useState<{ message: string; type: "success" | "error" } | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<"all" | "wishlist" | "visited">("all")

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push("/")
      return
    }
    loadPlaces()
    loadProfile()
  }, [router])

  const loadPlaces = () => {
    const currentUser = getCurrentUser()
    if (currentUser) {
      const userPlaces = getPlaces(currentUser)
      setPlaces(userPlaces)
    }
  }

  const loadProfile = () => {
    const currentUser = getCurrentUser()
    if (currentUser) {
      const profile = getProfile(currentUser)
      setUserProfile({ name: profile.name, photoUrl: profile.photoUrl })
    }
  }

  useEffect(() => {
    filterPlaces()
  }, [places, searchQuery, statusFilter])

  const filterPlaces = () => {
    let filtered = [...places]

    if (statusFilter !== "all") {
      filtered = filtered.filter((p) => p.status === statusFilter)
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter((p) => p.name.toLowerCase().includes(query) || p.country.toLowerCase().includes(query))
    }

    setFilteredPlaces(filtered)
  }

  const handleSave = (data: {
    name: string
    country: string
    description: string
    photoUrl: string
    status: "wishlist" | "visited"
  }) => {
    const currentUser = getCurrentUser()
    if (!currentUser) return

    let result
    if (editingPlace) {
      result = updatePlace(editingPlace.id, data)
    } else {
      result = addPlace({ ...data, userId: currentUser })
    }

    setNotification({ message: result.message, type: result.success ? "success" : "error" })

    if (result.success) {
      loadPlaces()
      setDialogOpen(false)
      setEditingPlace(null)
    }
  }

  const handleEdit = (place: Place) => {
    setEditingPlace(place)
    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm("Вы уверены, что хотите удалить это место?")) {
      const result = deletePlace(id)
      setNotification({ message: result.message, type: result.success ? "success" : "error" })
      if (result.success) {
        loadPlaces()
      }
    }
  }

  const handleToggleStatus = (id: string) => {
    const result = toggleStatus(id)
    setNotification({ message: result.message, type: result.success ? "success" : "error" })
    if (result.success) {
      loadPlaces()
    }
  }

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const handleAddNew = () => {
    setEditingPlace(null)
    setDialogOpen(true)
  }

  const handleOpenProfile = () => {
    setProfileDialogOpen(true)
  }

  const handleProfileUpdate = () => {
    loadProfile()
    setNotification({ message: "Профиль обновлен!", type: "success" })
  }

  const currentUser = getCurrentUser()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
      {notification && (
        <Notification message={notification.message} type={notification.type} onClose={() => setNotification(null)} />
      )}

      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={handleOpenProfile} className="flex items-center gap-3 hover:opacity-80 transition">
              {userProfile.photoUrl ? (
                <img
                  src={userProfile.photoUrl || "/placeholder.svg"}
                  alt="Profile"
                  className="h-10 w-10 rounded-full object-cover"
                />
              ) : (
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                  <User className="h-5 w-5 text-white" />
                </div>
              )}
            </button>
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2">
                <Plane className="h-5 w-5 text-blue-500" />
                {userProfile.name || "Travel Wishlist"}
              </h1>
              <p className="text-xs text-muted-foreground">{currentUser}</p>
            </div>
          </div>

          <Button onClick={handleLogout} variant="ghost" size="sm">
            <LogOut className="h-4 w-4 mr-2" />
            Выход
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold">Мои места</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Всего: {places.length} | В планах: {places.filter((p) => p.status === "wishlist").length} | Посещено:{" "}
                {places.filter((p) => p.status === "visited").length}
              </p>
            </div>

            <Button onClick={handleAddNew} size="lg" className="shadow-lg">
              <Plus className="h-5 w-5 mr-2" />
              Добавить место
            </Button>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Поиск по названию или стране..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as typeof statusFilter)}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все места</SelectItem>
                <SelectItem value="wishlist">В планах</SelectItem>
                <SelectItem value="visited">Посещено</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {filteredPlaces.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-24 w-24 rounded-full bg-muted flex items-center justify-center mb-4">
              <Plane className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">{places.length === 0 ? "Нет мест" : "Ничего не найдено"}</h3>
            <p className="text-muted-foreground mb-6">
              {places.length === 0
                ? "Добавьте первое место в ваш список путешествий"
                : "Попробуйте изменить фильтры или поисковый запрос"}
            </p>
            {places.length === 0 && (
              <Button onClick={handleAddNew} size="lg">
                <Plus className="h-5 w-5 mr-2" />
                Добавить место
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPlaces.map((place) => (
              <PlaceCard
                key={place.id}
                place={place}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onToggleStatus={handleToggleStatus}
              />
            ))}
          </div>
        )}
      </main>

      <PlaceDialog open={dialogOpen} onOpenChange={setDialogOpen} place={editingPlace} onSave={handleSave} />

      {currentUser && (
        <ProfileDialog
          open={profileDialogOpen}
          onOpenChange={setProfileDialogOpen}
          userEmail={currentUser}
          onUpdate={handleProfileUpdate}
        />
      )}
    </div>
  )
}
